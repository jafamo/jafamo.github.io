<?php
print '
<form method="get" action="ccmail/index.php">
<table border="0" cellpadding="0" cellspacing="0"><tr><td width="100%">
<b><div class="standard">Insert your Email Address:</div></b>
<input name="address" size="15" style=\"font-size:12px; font-family: Verdana, Geneva, Arial, Helvetica, \"Nimbus Sans L\", sans-serif;\">
<input type="submit" value="Go" style=\"font-size:12px; font-family: Verdana, Geneva, Arial, Helvetica, \"Nimbus Sans L\", sans-serif;\"><br><br>
</td></tr></table></form>
';
?>